import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
interface Componente{
  icon: string;
  name: string;
  redirecTo: string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(private alertController: AlertController) {}

  async Consulta(){
    const alert = await this.alertController.create({
      header: 'Cerrar Sesión',
      message: 'Está segur@ de Cerrar Sesión?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
        },
        {
          text: 'Si',
          role: 'confirm',
        },
      ],
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
  }

  componentes: Componente[]=[
    {
      icon: 'phone-portrait-outline',
      name: 'RegistrApp',
      redirecTo: '/registr-app'
    },

    {
      icon: 'people-circle-outline',
      name: 'Start',
      redirecTo: '/start-app'
    },

    {
      icon: 'person-circle-outline',
      name: 'Login',
      redirecTo: '/login'
    },

    {
      icon: 'document-text-outline',
      name: 'Registro',
      redirecTo: '/registro'
    },

    {
      icon: 'home-outline',
      name: 'Inicio',
      redirecTo: '/inicio'
    },

    {
      icon: 'school-outline',
      name: 'Secciones',
      redirecTo: '/secciones',
    },

    {
      icon: 'library-outline',
      name: 'Seccion (XXXX)',
      redirecTo: '/seccion',
    },

    {
      icon: 'qr-code-outline',
      name: 'Generar QR',
      redirecTo: '/generar-qr',
    },

    {
      icon: 'scan-outline',
      name: 'Lector QR',
      redirecTo: '/lector-qr',
    },

    {
      icon: 'arrow-back-circle-outline',
      name: 'Cerrar Sesión',
      redirecTo: '/inicio' ,
    },
  ];
}
