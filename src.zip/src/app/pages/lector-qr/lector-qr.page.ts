import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
@Component({
  selector: 'app-lector-qr',
  templateUrl: './lector-qr.page.html',
  styleUrls: ['./lector-qr.page.scss'],
})
export class LectorQrPage implements OnInit {

  constructor(private menuController: MenuController,
              private alertController: AlertController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }

  async aRegistrada(){
    const alert = await this.alertController.create({
      header: 'Asistencia Registrada!',
      message: 'Se ha registrado tu asistencia en la sección: (SECCIÓN) correspondiente al día (DÍA Y HORA).',
      buttons: ['OK'],
    });

    await alert.present();
  }
}
