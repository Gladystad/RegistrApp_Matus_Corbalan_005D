import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
interface Cursos{
  name: string;
  redirecTo: string;
}

@Component({
  selector: 'app-secciones',
  templateUrl: './secciones.page.html',
  styleUrls: ['./secciones.page.scss'],
})
export class SeccionesPage implements OnInit {

  constructor(private menuController: MenuController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }

  cursos : Cursos[]=[
    {
      name: 'Login',
      redirecTo: '/login',
    },
    
  ]
}
