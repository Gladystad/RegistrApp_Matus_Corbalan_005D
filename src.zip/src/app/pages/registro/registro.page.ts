import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  constructor(private menuController: MenuController,
              private alertController: AlertController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }

  usuarioR={
    nombre:'',
    rut: '',
    email: '',
    password:'',
    password2:'',
  }

  onSubmit(){
    console.log('Submit');
    console.log(this.usuarioR);
  }

  async CrearCuenta(){
    const alert = await this.alertController.create({
      header: 'Cuenta Creada',
      message: 'Su cuenta ha sido creada con éxito! ^^',
      buttons: ['OK'],
    });

    await alert.present();
  }

}
