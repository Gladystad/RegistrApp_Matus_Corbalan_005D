import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(private menuController: MenuController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }

  //FORMULARIO DE LOGIN
  usuario={
    usuario:'',
    password:'',
  }

  onSubmit(){
    console.log('Submit');
    console.log(this.usuario);
  }
}
