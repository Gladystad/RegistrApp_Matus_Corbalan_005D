import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-generar-qr',
  templateUrl: './generar-qr.page.html',
  styleUrls: ['./generar-qr.page.scss'],
})
export class GenerarQrPage implements OnInit {

  constructor(private menuController: MenuController, 
              private alertController: AlertController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }
  async GuardarAsistencia(){
    const alert = await this.alertController.create({
      header: 'Asistencia Guardada!',
      message: 'Se ha registrado la asistencia de la sección: (SECCIÓN) correspondiente al día (DÍA Y HORA).',
      
      buttons: ['OK'],
    });

    await alert.present();
  }

}
