import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-registr-app',
  templateUrl: './registr-app.page.html',
  styleUrls: ['./registr-app.page.scss'],
})
export class RegistrAppPage implements OnInit {

  constructor(private menuController: MenuController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }
}
