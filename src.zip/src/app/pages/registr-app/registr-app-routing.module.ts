import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegistrAppPage } from './registr-app.page';

const routes: Routes = [
  {
    path: '',
    component: RegistrAppPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegistrAppPageRoutingModule {}
