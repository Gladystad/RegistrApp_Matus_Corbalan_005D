import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegistrAppPageRoutingModule } from './registr-app-routing.module';

import { RegistrAppPage } from './registr-app.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegistrAppPageRoutingModule
  ],
  declarations: [RegistrAppPage]
})
export class RegistrAppPageModule {}
